extends StaticBody2D

@export var rotate_speed = 120.0

func _process(delta):
	rotation_degrees += rotate_speed * delta
