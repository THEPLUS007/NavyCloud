extends Camera2D

@onready var player = $"../Player"

func _process(delta):
	global_position.y = player.global_position.y
