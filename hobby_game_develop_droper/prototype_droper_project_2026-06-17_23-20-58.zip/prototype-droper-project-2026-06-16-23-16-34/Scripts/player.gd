extends CharacterBody2D

@export var move_speed = 500

var gravity_speed = 0

func _physics_process(delta):

	gravity_speed += 100 * delta

	velocity.y = gravity_speed

	var direction = Input.get_axis(
		"ui_left",
        "ui_right"
	if Input.is_action_pressed("ui_accept"):
		Engine.time_scale = 0.3
	else:
		Engine.time_scale = 1.0
	)

	velocity.x = direction * move_speed

	move_and_slide()
