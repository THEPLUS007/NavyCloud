extends Node2D

var score = 0

@onready var label = $CanvasLayer/Label

func _process(delta):

	score += delta

	label.text = "Score : " + str(int(score))
